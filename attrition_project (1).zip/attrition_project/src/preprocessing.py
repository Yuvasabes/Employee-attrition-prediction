"""
preprocessing.py

Loads raw HR data and builds a scikit-learn preprocessing pipeline
(imputation + scaling for numeric features, one-hot encoding for
categorical features). Returns a fitted ColumnTransformer plus the
train/test split, ready to feed into any classifier.
"""

import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

TARGET_COL = "Attrition"
ID_COLS = ["EmployeeNumber"]  # dropped, not predictive


def load_data(path="data/employee_data.csv"):
    df = pd.read_csv(path)
    return df


def split_features_target(df):
    df = df.copy()
    for col in ID_COLS:
        if col in df.columns:
            df = df.drop(columns=col)

    y = (df[TARGET_COL] == "Yes").astype(int)
    X = df.drop(columns=[TARGET_COL])
    return X, y


def build_preprocessor(X):
    numeric_cols = X.select_dtypes(include=["int64", "float64"]).columns.tolist()
    categorical_cols = X.select_dtypes(include=["object"]).columns.tolist()

    numeric_pipeline = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler()),
    ])

    categorical_pipeline = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore")),
    ])

    preprocessor = ColumnTransformer(transformers=[
        ("num", numeric_pipeline, numeric_cols),
        ("cat", categorical_pipeline, categorical_cols),
    ])

    return preprocessor, numeric_cols, categorical_cols


def get_train_test_split(path="data/employee_data.csv", test_size=0.2, random_state=42):
    df = load_data(path)
    X, y = split_features_target(df)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state, stratify=y
    )
    return X_train, X_test, y_train, y_test
