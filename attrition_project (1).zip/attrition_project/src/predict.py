"""
predict.py

Loads the trained model pipeline and scores new employee records for
attrition risk.

Usage:
    # score a CSV of new employees (same columns as training data, minus Attrition)
    python3 src/predict.py --input data/new_employees.csv --output outputs/predictions.csv

    # or score a single employee from a JSON file
    python3 src/predict.py --input data/single_employee.json
"""

import argparse
import json

import joblib
import pandas as pd

MODEL_PATH = "models/attrition_model.pkl"


def load_model():
    return joblib.load(MODEL_PATH)


def predict_dataframe(pipeline, df):
    proba = pipeline.predict_proba(df)[:, 1]
    pred = pipeline.predict(df)
    result = df.copy()
    result["Attrition_Risk_Probability"] = proba.round(4)
    result["Predicted_Attrition"] = pd.Series(pred).map({1: "Yes", 0: "No"})
    result["Risk_Level"] = pd.cut(
        proba, bins=[-0.01, 0.3, 0.6, 1.01], labels=["Low", "Medium", "High"]
    )
    return result.sort_values("Attrition_Risk_Probability", ascending=False)


def main():
    parser = argparse.ArgumentParser(description="Predict employee attrition risk.")
    parser.add_argument("--input", required=True, help="Path to input CSV or JSON file")
    parser.add_argument("--output", default="outputs/predictions.csv", help="Path to save predictions CSV")
    args = parser.parse_args()

    pipeline = load_model()

    if args.input.endswith(".json"):
        with open(args.input) as f:
            record = json.load(f)
        df = pd.DataFrame([record]) if isinstance(record, dict) else pd.DataFrame(record)
    else:
        df = pd.read_csv(args.input)

    # drop target/id columns if present, so it works even if user reuses training data
    for col in ["Attrition", "EmployeeNumber"]:
        if col in df.columns:
            df = df.drop(columns=col)

    result = predict_dataframe(pipeline, df)
    result.to_csv(args.output, index=False)

    print(f"Scored {len(result)} employee(s). Saved -> {args.output}\n")
    print(result[["Attrition_Risk_Probability", "Predicted_Attrition", "Risk_Level"]].head(10).to_string())


if __name__ == "__main__":
    main()
