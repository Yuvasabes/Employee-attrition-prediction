"""
generate_dataset.py

Generates a synthetic employee attrition dataset modeled on the structure
and feature set of the well-known IBM HR Analytics Employee Attrition dataset.

NOTE: If you have your own company HR data, skip this script entirely and
just place your CSV at data/employee_data.csv with an 'Attrition' target
column (Yes/No). Everything downstream (train.py, evaluate.py, predict.py)
will work unchanged as long as column names roughly match, or you adjust
the CONFIG in train.py.
"""

import numpy as np
import pandas as pd

np.random.seed(42)

N = 1470  # same size as the classic IBM dataset

def generate_dataset(n=N):
    df = pd.DataFrame()

    df["Age"] = np.random.randint(18, 61, n)
    df["Gender"] = np.random.choice(["Male", "Female"], n)
    df["MaritalStatus"] = np.random.choice(["Single", "Married", "Divorced"], n, p=[0.32, 0.46, 0.22])
    df["Department"] = np.random.choice(
        ["Sales", "Research & Development", "Human Resources"], n, p=[0.30, 0.60, 0.10]
    )
    df["EducationField"] = np.random.choice(
        ["Life Sciences", "Medical", "Marketing", "Technical Degree", "Human Resources", "Other"],
        n, p=[0.35, 0.25, 0.12, 0.14, 0.06, 0.08]
    )
    df["Education"] = np.random.randint(1, 6, n)  # 1=Below College ... 5=Doctor
    df["JobRole"] = np.random.choice(
        ["Sales Executive", "Research Scientist", "Laboratory Technician", "Manufacturing Director",
         "Healthcare Representative", "Manager", "Sales Representative", "Research Director", "Human Resources"],
        n
    )
    df["JobLevel"] = np.random.randint(1, 6, n)
    df["BusinessTravel"] = np.random.choice(
        ["Non-Travel", "Travel_Rarely", "Travel_Frequently"], n, p=[0.10, 0.71, 0.19]
    )
    df["DistanceFromHome"] = np.random.randint(1, 30, n)

    df["MonthlyIncome"] = (df["JobLevel"] * 2500 + np.random.normal(0, 1500, n)).clip(1000, 20000).astype(int)
    df["PercentSalaryHike"] = np.random.randint(11, 26, n)
    df["StockOptionLevel"] = np.random.randint(0, 4, n)

    df["TotalWorkingYears"] = np.clip(df["Age"] - np.random.randint(18, 24, n), 0, None)
    df["YearsAtCompany"] = np.clip(
        (df["TotalWorkingYears"] * np.random.uniform(0.2, 0.9, n)).astype(int), 0, None
    )
    df["YearsInCurrentRole"] = np.clip((df["YearsAtCompany"] * np.random.uniform(0.2, 0.8, n)).astype(int), 0, None)
    df["YearsSinceLastPromotion"] = np.clip((df["YearsAtCompany"] * np.random.uniform(0, 0.5, n)).astype(int), 0, None)
    df["YearsWithCurrManager"] = np.clip((df["YearsAtCompany"] * np.random.uniform(0.2, 0.8, n)).astype(int), 0, None)
    df["NumCompaniesWorked"] = np.random.randint(0, 10, n)
    df["TrainingTimesLastYear"] = np.random.randint(0, 7, n)

    df["JobSatisfaction"] = np.random.randint(1, 5, n)          # 1=Low ... 4=Very High
    df["EnvironmentSatisfaction"] = np.random.randint(1, 5, n)
    df["RelationshipSatisfaction"] = np.random.randint(1, 5, n)
    df["WorkLifeBalance"] = np.random.randint(1, 5, n)
    df["JobInvolvement"] = np.random.randint(1, 5, n)
    df["PerformanceRating"] = np.random.choice([3, 4], n, p=[0.85, 0.15])

    df["OverTime"] = np.random.choice(["Yes", "No"], n, p=[0.28, 0.72])
    df["EmployeeNumber"] = np.arange(1, n + 1)

    # ----- Build a realistic attrition probability from a weighted risk score -----
    risk = np.zeros(n)
    risk += (df["OverTime"] == "Yes") * 1.6
    risk += (4 - df["JobSatisfaction"]) * 0.55
    risk += (4 - df["WorkLifeBalance"]) * 0.45
    risk += (4 - df["EnvironmentSatisfaction"]) * 0.35
    risk += (df["DistanceFromHome"] > 15) * 0.5
    risk += (df["MonthlyIncome"] < 3500) * 0.9
    risk += (df["YearsAtCompany"] < 2) * 0.7
    risk += (df["Age"] < 30) * 0.4
    risk += (df["BusinessTravel"] == "Travel_Frequently") * 0.5
    risk += (df["NumCompaniesWorked"] > 4) * 0.3
    risk += (df["YearsSinceLastPromotion"] > 5) * 0.4
    risk += (df["MaritalStatus"] == "Single") * 0.3
    risk -= (df["StockOptionLevel"] > 1) * 0.4
    risk -= (df["JobLevel"] > 3) * 0.5

    # convert risk score to probability via logistic function, then sample
    prob = 1 / (1 + np.exp(-(risk - risk.mean())))
    # rescale so overall attrition rate lands close to the real dataset's ~16%
    prob = prob * (0.16 / prob.mean())
    prob = prob.clip(0.01, 0.95)

    df["Attrition"] = np.where(np.random.rand(n) < prob, "Yes", "No")

    return df


if __name__ == "__main__":
    df = generate_dataset()
    out_path = "data/employee_data.csv"
    df.to_csv(out_path, index=False)
    print(f"Generated {len(df)} rows -> {out_path}")
    print(f"Attrition rate: {(df['Attrition'] == 'Yes').mean():.2%}")
    print(df.head())
