"""
evaluate.py

Loads the saved model pipeline and produces evaluation artifacts:
- confusion matrix plot
- ROC curve plot
- feature importance plot (for tree-based models) or coefficient plot
  (for logistic regression)

Outputs are saved as PNGs in outputs/

Usage:
    python3 src/evaluate.py
"""

import joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from sklearn.metrics import ConfusionMatrixDisplay, RocCurveDisplay, confusion_matrix

from preprocessing import get_train_test_split

MODEL_PATH = "models/attrition_model.pkl"


def get_feature_names(pipeline):
    preprocessor = pipeline.named_steps["preprocessor"]
    return preprocessor.get_feature_names_out()


def plot_confusion_matrix(pipeline, X_test, y_test):
    y_pred = pipeline.predict(X_test)
    cm = confusion_matrix(y_test, y_pred)
    disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=["Stayed", "Left"])
    fig, ax = plt.subplots(figsize=(5, 5))
    disp.plot(ax=ax, cmap="Blues", colorbar=False)
    ax.set_title("Confusion Matrix - Attrition Prediction")
    fig.tight_layout()
    fig.savefig("outputs/confusion_matrix.png", dpi=150)
    plt.close(fig)
    print("Saved outputs/confusion_matrix.png")


def plot_roc_curve(pipeline, X_test, y_test):
    fig, ax = plt.subplots(figsize=(6, 5))
    RocCurveDisplay.from_estimator(pipeline, X_test, y_test, ax=ax)
    ax.set_title("ROC Curve - Attrition Prediction")
    ax.plot([0, 1], [0, 1], linestyle="--", color="gray", label="Chance")
    fig.tight_layout()
    fig.savefig("outputs/roc_curve.png", dpi=150)
    plt.close(fig)
    print("Saved outputs/roc_curve.png")


def plot_feature_importance(pipeline, top_n=15):
    clf = pipeline.named_steps["classifier"]
    feature_names = get_feature_names(pipeline)

    if hasattr(clf, "feature_importances_"):
        importances = clf.feature_importances_
        title = "Top Feature Importances"
    elif hasattr(clf, "coef_"):
        importances = np.abs(clf.coef_[0])
        title = "Top Feature Coefficients (abs value)"
    else:
        print("Model type has no interpretable feature importances; skipping plot.")
        return

    order = np.argsort(importances)[::-1][:top_n]
    top_features = np.array(feature_names)[order]
    top_importances = importances[order]

    fig, ax = plt.subplots(figsize=(8, 6))
    ax.barh(range(len(top_features)), top_importances[::-1], color="#4C72B0")
    ax.set_yticks(range(len(top_features)))
    ax.set_yticklabels([f.split("__")[-1] for f in top_features[::-1]])
    ax.set_title(title)
    ax.set_xlabel("Importance")
    fig.tight_layout()
    fig.savefig("outputs/feature_importance.png", dpi=150)
    plt.close(fig)
    print("Saved outputs/feature_importance.png")


def main():
    pipeline = joblib.load(MODEL_PATH)
    _, X_test, _, y_test = get_train_test_split()

    plot_confusion_matrix(pipeline, X_test, y_test)
    plot_roc_curve(pipeline, X_test, y_test)
    plot_feature_importance(pipeline)


if __name__ == "__main__":
    main()
