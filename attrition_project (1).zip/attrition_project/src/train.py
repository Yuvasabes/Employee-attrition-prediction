"""
train.py

Trains several classifiers for employee attrition prediction, compares
them via cross-validation and a held-out test set, and saves the best
performing model (full pipeline: preprocessing + classifier) to
models/attrition_model.pkl

Usage:
    python3 src/train.py
"""

import json

import joblib
import pandas as pd
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    f1_score,
    roc_auc_score,
)
from sklearn.model_selection import cross_val_score
from sklearn.pipeline import Pipeline

from preprocessing import build_preprocessor, get_train_test_split

MODEL_PATH = "models/attrition_model.pkl"
METRICS_PATH = "outputs/metrics.json"

MODELS = {
    "LogisticRegression": LogisticRegression(max_iter=1000, class_weight="balanced"),
    "RandomForest": RandomForestClassifier(
        n_estimators=300, max_depth=8, random_state=42, class_weight="balanced"
    ),
    "GradientBoosting": GradientBoostingClassifier(
        n_estimators=200, max_depth=3, learning_rate=0.05, random_state=42
    ),
}


def main():
    X_train, X_test, y_train, y_test = get_train_test_split()
    preprocessor, numeric_cols, categorical_cols = build_preprocessor(X_train)

    results = {}
    fitted_pipelines = {}

    for name, clf in MODELS.items():
        pipe = Pipeline(steps=[("preprocessor", preprocessor), ("classifier", clf)])

        cv_scores = cross_val_score(pipe, X_train, y_train, cv=5, scoring="roc_auc")
        pipe.fit(X_train, y_train)

        y_pred = pipe.predict(X_test)
        y_proba = pipe.predict_proba(X_test)[:, 1]

        acc = accuracy_score(y_test, y_pred)
        f1 = f1_score(y_test, y_pred)
        auc = roc_auc_score(y_test, y_proba)

        results[name] = {
            "cv_roc_auc_mean": round(cv_scores.mean(), 4),
            "cv_roc_auc_std": round(cv_scores.std(), 4),
            "test_accuracy": round(acc, 4),
            "test_f1": round(f1, 4),
            "test_roc_auc": round(auc, 4),
        }
        fitted_pipelines[name] = pipe

        print(f"\n=== {name} ===")
        print(f"CV ROC-AUC: {cv_scores.mean():.4f} (+/- {cv_scores.std():.4f})")
        print(f"Test Accuracy: {acc:.4f} | Test F1: {f1:.4f} | Test ROC-AUC: {auc:.4f}")
        print(classification_report(y_test, y_pred, target_names=["Stayed", "Left"]))

    # pick best model by test ROC-AUC
    best_name = max(results, key=lambda k: results[k]["test_roc_auc"])
    best_pipeline = fitted_pipelines[best_name]

    print(f"\n>>> Best model: {best_name} (test ROC-AUC = {results[best_name]['test_roc_auc']})")

    joblib.dump(best_pipeline, MODEL_PATH)
    print(f"Saved best model pipeline -> {MODEL_PATH}")

    with open(METRICS_PATH, "w") as f:
        json.dump({"results": results, "best_model": best_name}, f, indent=2)
    print(f"Saved metrics -> {METRICS_PATH}")


if __name__ == "__main__":
    main()
