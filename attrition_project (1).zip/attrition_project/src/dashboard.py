"""
dashboard.py

Interactive web dashboard for the Employee Attrition Prediction project.
Built with Streamlit.

Run with:
    streamlit run src/dashboard.py

Features:
- Model performance overview (metrics, confusion matrix, ROC curve, feature importance)
- Upload a CSV of employees and get live attrition risk predictions
- Single-employee "what-if" risk calculator with sliders/dropdowns
- Downloadable predictions
"""

import json
import os

import joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import streamlit as st
from sklearn.metrics import ConfusionMatrixDisplay, RocCurveDisplay, confusion_matrix

import sys
sys.path.append(os.path.dirname(__file__))
from preprocessing import get_train_test_split

MODEL_PATH = "models/attrition_model.pkl"
METRICS_PATH = "outputs/metrics.json"
DATA_PATH = "data/employee_data.csv"

st.set_page_config(page_title="Employee Attrition Dashboard", layout="wide")


@st.cache_resource
def load_model():
    return joblib.load(MODEL_PATH)


@st.cache_data
def load_metrics():
    if os.path.exists(METRICS_PATH):
        with open(METRICS_PATH) as f:
            return json.load(f)
    return None


@st.cache_data
def load_reference_data():
    return pd.read_csv(DATA_PATH)


def get_feature_names(pipeline):
    return pipeline.named_steps["preprocessor"].get_feature_names_out()


# ---------------------------------------------------------------------------
st.title("🧑‍💼 Employee Attrition Prediction Dashboard")
st.caption("Predicting which employees are at risk of leaving, using HR data.")

if not os.path.exists(MODEL_PATH):
    st.error(
        "No trained model found at `models/attrition_model.pkl`. "
        "Run `python src/train.py` first, then reload this dashboard."
    )
    st.stop()

pipeline = load_model()
metrics = load_metrics()
ref_df = load_reference_data()

tab1, tab2, tab3 = st.tabs(
    ["📊 Model Overview", "📁 Upload & Predict", "🎛️ Single Employee Calculator"]
)

# ---------------------------------------------------------------------------
# TAB 1: Model Overview
# ---------------------------------------------------------------------------
with tab1:
    st.subheader("Model Comparison")

    if metrics:
        best = metrics["best_model"]
        results_df = pd.DataFrame(metrics["results"]).T
        results_df = results_df.rename_axis("Model").reset_index()
        st.dataframe(results_df, use_container_width=True)
        st.success(f"Best model selected: **{best}** (highest test ROC-AUC)")
    else:
        st.warning("No metrics.json found. Run `python src/train.py` to generate it.")

    st.divider()
    st.subheader("Evaluation Plots")

    col1, col2 = st.columns(2)

    _, X_test, _, y_test = get_train_test_split()

    with col1:
        st.markdown("**Confusion Matrix**")
        y_pred = pipeline.predict(X_test)
        cm = confusion_matrix(y_test, y_pred)
        fig, ax = plt.subplots(figsize=(4, 4))
        ConfusionMatrixDisplay(cm, display_labels=["Stayed", "Left"]).plot(
            ax=ax, cmap="Blues", colorbar=False
        )
        st.pyplot(fig)

    with col2:
        st.markdown("**ROC Curve**")
        fig2, ax2 = plt.subplots(figsize=(4, 4))
        RocCurveDisplay.from_estimator(pipeline, X_test, y_test, ax=ax2)
        ax2.plot([0, 1], [0, 1], linestyle="--", color="gray")
        st.pyplot(fig2)

    st.markdown("**Feature Importance**")
    clf = pipeline.named_steps["classifier"]
    feature_names = get_feature_names(pipeline)

    if hasattr(clf, "feature_importances_"):
        importances = clf.feature_importances_
    elif hasattr(clf, "coef_"):
        importances = np.abs(clf.coef_[0])
    else:
        importances = None

    if importances is not None:
        order = np.argsort(importances)[::-1][:15]
        top_features = [feature_names[i].split("__")[-1] for i in order]
        top_values = importances[order]
        fig3, ax3 = plt.subplots(figsize=(8, 5))
        ax3.barh(range(len(top_features)), top_values[::-1], color="#4C72B0")
        ax3.set_yticks(range(len(top_features)))
        ax3.set_yticklabels(top_features[::-1])
        ax3.set_title("Top 15 Feature Importances")
        st.pyplot(fig3)

# ---------------------------------------------------------------------------
# TAB 2: Upload & Predict
# ---------------------------------------------------------------------------
with tab2:
    st.subheader("Upload Employee Data for Batch Prediction")
    st.write(
        "Upload a CSV with the same columns as the training data "
        "(no `Attrition` column needed). We'll predict risk for each employee."
    )

    uploaded = st.file_uploader("Upload CSV", type=["csv"])

    demo_col1, demo_col2 = st.columns([1, 3])
    with demo_col1:
        use_demo = st.button("Use sample data instead")

    input_df = None
    if uploaded is not None:
        input_df = pd.read_csv(uploaded)
    elif use_demo:
        input_df = ref_df.drop(columns=["Attrition"]).sample(15, random_state=7)

    if input_df is not None:
        df = input_df.copy()
        for col in ["Attrition", "EmployeeNumber"]:
            if col in df.columns:
                df = df.drop(columns=col)

        proba = pipeline.predict_proba(df)[:, 1]
        pred = pipeline.predict(df)

        result = input_df.copy()
        result["Attrition_Risk_Probability"] = proba.round(4)
        result["Predicted_Attrition"] = pd.Series(pred).map({1: "Yes", 0: "No"})
        result["Risk_Level"] = pd.cut(
            proba, bins=[-0.01, 0.3, 0.6, 1.01], labels=["Low", "Medium", "High"]
        )
        result = result.sort_values("Attrition_Risk_Probability", ascending=False)

        st.write(f"### Results ({len(result)} employees)")

        c1, c2, c3 = st.columns(3)
        c1.metric("High Risk", int((result["Risk_Level"] == "High").sum()))
        c2.metric("Medium Risk", int((result["Risk_Level"] == "Medium").sum()))
        c3.metric("Low Risk", int((result["Risk_Level"] == "Low").sum()))

        def highlight_risk(row):
            color = {"High": "#ffcccc", "Medium": "#fff3cd", "Low": "#d4edda"}.get(
                row["Risk_Level"], ""
            )
            return [f"background-color: {color}"] * len(row)

        st.dataframe(result.style.apply(highlight_risk, axis=1), use_container_width=True)

        csv_bytes = result.to_csv(index=False).encode("utf-8")
        st.download_button(
            "⬇️ Download predictions as CSV",
            data=csv_bytes,
            file_name="predictions.csv",
            mime="text/csv",
        )
    else:
        st.info("Upload a CSV file or click 'Use sample data instead' to see it in action.")

# ---------------------------------------------------------------------------
# TAB 3: Single Employee Calculator
# ---------------------------------------------------------------------------
with tab3:
    st.subheader("What-If Risk Calculator")
    st.write("Adjust an employee's profile below to see how their attrition risk changes.")

    col1, col2, col3 = st.columns(3)

    with col1:
        age = st.slider("Age", 18, 60, 30)
        monthly_income = st.slider("Monthly Income ($)", 1000, 20000, 5000, step=500)
        distance = st.slider("Distance From Home (km)", 1, 30, 10)
        years_at_company = st.slider("Years at Company", 0, 40, 3)
        job_level = st.slider("Job Level", 1, 5, 2)

    with col2:
        overtime = st.selectbox("OverTime", ["Yes", "No"])
        job_satisfaction = st.select_slider("Job Satisfaction", [1, 2, 3, 4], value=3)
        work_life_balance = st.select_slider("Work-Life Balance", [1, 2, 3, 4], value=3)
        env_satisfaction = st.select_slider("Environment Satisfaction", [1, 2, 3, 4], value=3)
        marital_status = st.selectbox("Marital Status", ["Single", "Married", "Divorced"])

    with col3:
        business_travel = st.selectbox(
            "Business Travel", ["Non-Travel", "Travel_Rarely", "Travel_Frequently"]
        )
        department = st.selectbox(
            "Department", ["Sales", "Research & Development", "Human Resources"]
        )
        stock_option = st.slider("Stock Option Level", 0, 3, 1)
        num_companies = st.slider("Num Companies Worked", 0, 9, 2)
        years_since_promo = st.slider("Years Since Last Promotion", 0, 15, 1)

    # build a single-row dataframe matching training schema; fill remaining
    # columns with reasonable defaults pulled from the reference dataset
    template = ref_df.drop(columns=["Attrition", "EmployeeNumber"]).iloc[0:1].copy()

    template["Age"] = age
    template["MonthlyIncome"] = monthly_income
    template["DistanceFromHome"] = distance
    template["YearsAtCompany"] = years_at_company
    template["JobLevel"] = job_level
    template["OverTime"] = overtime
    template["JobSatisfaction"] = job_satisfaction
    template["WorkLifeBalance"] = work_life_balance
    template["EnvironmentSatisfaction"] = env_satisfaction
    template["MaritalStatus"] = marital_status
    template["BusinessTravel"] = business_travel
    template["Department"] = department
    template["StockOptionLevel"] = stock_option
    template["NumCompaniesWorked"] = num_companies
    template["YearsSinceLastPromotion"] = years_since_promo
    # keep dependent columns roughly consistent
    template["YearsInCurrentRole"] = min(years_at_company, template["YearsInCurrentRole"].iloc[0])
    template["YearsWithCurrManager"] = min(years_at_company, template["YearsWithCurrManager"].iloc[0])
    template["TotalWorkingYears"] = max(years_at_company, template["TotalWorkingYears"].iloc[0])

    risk_proba = pipeline.predict_proba(template)[0, 1]
    risk_label = "High" if risk_proba > 0.6 else ("Medium" if risk_proba > 0.3 else "Low")
    color = {"High": "🔴", "Medium": "🟡", "Low": "🟢"}[risk_label]

    st.divider()
    st.metric("Predicted Attrition Risk", f"{risk_proba:.1%}", f"{color} {risk_label} risk")
    st.progress(min(risk_proba, 1.0))
